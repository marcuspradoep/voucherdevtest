tuple=(1,2,3,4,0,5,6)
for i in tuple:
    if i==0:
        print("zero encontrado")
    else:
        print("nenhum zero encontrado")