tupla=(1,40,2)
for i in tupla:
    if i>5:
        print(i)