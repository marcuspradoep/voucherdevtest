tupla=(2,5,6)
s=0
for i in tupla:
    if i%2==0:
        s+=i
print(s)