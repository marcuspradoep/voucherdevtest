a=3

tupla=(3,6,2,9,1,7,5)
for i in tupla:
    if i>a:
        a=i

print(a)
