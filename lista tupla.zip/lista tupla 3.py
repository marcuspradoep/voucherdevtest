tupla=(2,5,6,7,4,9,8)
for i in tupla:
    if i%2==0:
        print(i)